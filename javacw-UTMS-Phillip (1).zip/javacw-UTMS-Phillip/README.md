# javacw
This group is composed of 10 people and collaborating on coursework project of a simple application that connects to a database in Java
